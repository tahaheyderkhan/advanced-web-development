import logo from './logo.svg';
import './App.css';
import MyImage from './assets/a-dramatic-black-and-white-studio-portra_Cj1VJo0nTaGHJ7NFy1yRAw_u2ajO3c-Sj-Gxe1iv9t9uQ.jpeg'

function App() {
  return (
    
    <div className="App">

      <h1>Welcome to My React Boilerplate</h1>

      <header className="App-header">
        <img src={MyImage} alt="Custom" width="250" style={{ borderRadius: '10px' }} />
        <p>
          My first React App with Custom Image.
        </p>
        <button 
        style={{
          marginTop: '20px',
          padding: '10px 20px',
          backgroundColor: '#61dafb',
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          fontSize: '16px'
        }}
      >
        Click Me
      </button>
      </header>
    </div>
  );
}

export default App;
